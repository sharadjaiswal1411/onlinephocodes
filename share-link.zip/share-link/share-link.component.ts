import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService,PostService,AuthenticationService } from '../services/index';
@Component({
  selector: 'app-share-link',
  templateUrl: './share-link.component.html',
  styleUrls: ['./share-link.component.css']
})
export class ShareLinkComponent implements OnInit {

  model:any={};
  invalidLink:boolean=false;
  myform:any={};
  loading:boolean=false;
  constructor( private router: Router,
      private postService: PostService,
      private alertService: AlertService,
  private authenticationService:AuthenticationService
  ) { }

  ngOnInit() {
   
  }


  validateUrl(){
            var re = /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
            if(re.test(this.model.link)){
                this.invalidLink=false;
                this.loading = true;
             this.postService.scrap(this.model.link)
            .subscribe(
                data => {
                  this.model.data=data;
                  
                },
                error => {
          
                  if(error.status==422){
                   this.invalidLink=true;
                           
                  }else if(error.status==401){
                    alert(error._body);
                    this.authenticationService.logout();
                    this.router.navigate(['/signin.html']);                         
                  }else{
                       //this.alertService.error(error);
                  }
          
           this.loading = false;
        });


            }else{
                this.invalidLink=true;
            }
  }  
 

}
